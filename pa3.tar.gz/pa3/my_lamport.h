
#ifndef __ROMCHIK_MY_LAMPORT_H
#define __ROMCHIK_MY_LAMPORT_H

#include "ipc.h"
#include "pipes.h"

timestamp_t my_get_lamport_time(global* gl);

#endif

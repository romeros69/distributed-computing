
#ifndef __ROMCHIK_TEST_H
#define __ROMCHIK_TEST_H

#include "pipes.h"

void test_add_elements_to_gen_pipes(size_t count_proc, chpok** gen);

#endif

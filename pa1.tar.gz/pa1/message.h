

#ifndef __ROMCHIK_MESSAGE_H
#define __ROMCHIK_MESSAGE_H
#include "ipc.h"
#include "pa1.h"

Message* new_started_msg(int id_proc);

#endif
